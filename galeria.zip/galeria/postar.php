<?php
// Conexão com o banco de dados
$host = 'localhost';   // Ou outro servidor, se necessário
$user = 'root';        // Seu usuário do MySQL
$password = '';        // Sua senha do MySQL
$dbname = 'galeria';   // Nome do banco de dados

$conn = new mysqli($host, $user, $password, $dbname);

if ($conn->connect_error) {
    die("Conexão falhou: " . $conn->connect_error);
}

// Verificar se o formulário foi enviado
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_FILES['imagem'])) {
    // Obter dados do formulário
    $titulo = $_POST['titulo'];
    
    // Garantir que o campo 'descricao' exista no POST, caso contrário, atribuir um valor padrão vazio
    $descricao = isset($_POST['descricao']) ? $_POST['descricao'] : '';

    $imagem = $_FILES['imagem'];

    // Verificar se não houve erro no upload
    if ($imagem['error'] == UPLOAD_ERR_OK) {
        // Definir diretório para salvar as imagens
        $diretorio = 'img/';

        // Verificar se o diretório existe, caso contrário, criar
        if (!is_dir($diretorio)) {
            mkdir($diretorio, 0777, true);
        }

        // Obter o nome do arquivo e criar o caminho
        $nome_arquivo = basename($imagem['name']);
        $caminho_arquivo = $diretorio . $nome_arquivo;

        // Mover o arquivo para o diretório de uploads
        if (move_uploaded_file($imagem['tmp_name'], $caminho_arquivo)) {
            // Inserir dados no banco de dados (ajustando para minúsculas e sem acento)
            $stmt = $conn->prepare("INSERT INTO post (titulo, path_imagem, descricao) VALUES (?, ?, ?)");
            $stmt->bind_param('sss', $titulo, $caminho_arquivo, $descricao);

            if ($stmt->execute()) {
                // Post enviado com sucesso, mostrar botão para ir à galeria
                echo "<p>Imagem enviada e registrada com sucesso!</p>";
                echo "<form action='galeria.php' method='get'>
                        <button type='submit' class='btn btn-primary'>Ir para a Galeria</button>
                      </form>";
            } else {
                echo "<p>Erro ao salvar no banco de dados.</p>";
            }

            $stmt->close();
        } else {
            echo "<p>Erro ao mover o arquivo para o diretório de uploads.</p>";
        }
    } else {
        echo "<p>Erro no upload da imagem.</p>";
    }
}

// Fechar a conexão com o banco de dados
$conn->close();
?>
