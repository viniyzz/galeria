<?php
// Conectar ao banco de dados diretamente em galeria.php
$host = 'localhost';
$user = 'root';
$password = '';
$dbname = 'galeria';

$conn = new mysqli($host, $user, $password, $dbname);

// Verificar conexão
if ($conn->connect_error) {
    die("Conexão falhou: " . $conn->connect_error);
}

// Buscar imagens do banco de dados
$sql = "SELECT id, titulo, path_Imagem, descricao FROM post ORDER BY id DESC LIMIT 6";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <link href="https://fonts.googleapis.com/css2?family=Roboto&display=swap" rel="stylesheet">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Galeria de Imagens com Vídeo de Fundo</title>
    <style>
        body {
    font-family: 'Roboto', sans-serif;
}

        /* Definindo o estilo do vídeo */
        .video-background {
            position: fixed;
            top: 0;
            left: 0;
            width: 100vw;
            height: 100vh;
            object-fit: cover;
            z-index: -1;
            filter: brightness(50%);
        }

        /* Estilo para as imagens sobrepostas */
        .overlay-images {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            z-index: 1;
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
            justify-content: center;
        }

        /* Ajustando a exibição das imagens */
        .overlay-images img {
            max-width: 200px;
            border-radius: 5px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.5);
            cursor: pointer;
            transition: transform 0.2s;
        }

        .overlay-images img:hover {
            transform: scale(1.05);
        }

        /* Estilo para o modal */
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100vw;
            height: 100vh;
            background-color: rgba(0, 0, 0, 0.8);
            color: white;
            z-index: 2;
            align-items: center;
            justify-content: center;
            text-align: center;
        }

        .modal-content {
            max-width: 80%;
            padding: 20px;
            background-color: #333;
            border-radius: 10px;
        }

        .modal button {
            background: none;
            border: none;
            color: white;
            font-size: 20px;
            cursor: pointer;
            position: absolute;
            top: 20px;
            right: 20px;
        }
    </style>
    <script>
        function showModal(titulo, descricao) {
            const modal = document.getElementById('imageModal');
            modal.style.display = 'flex';
            document.getElementById('modalTitle').innerText = titulo;
            document.getElementById('modalDescription').innerText = descricao;
        }

        function closeModal() {
            document.getElementById('imageModal').style.display = 'none';
        }
    </script>
</head>
<body>

<div class="video-wrapper">
    <video class="video-background" autoplay muted loop>
        <source src="img/animacaodovini.mp4" type="video/mp4">
    </video>
    <div class="overlay-images">
        <?php
        if ($result->num_rows > 0) {
            while($row = $result->fetch_assoc()) {
                echo '<img src="' . $row["path_Imagem"] . '" alt="' . $row["titulo"] . '" onclick="showModal(\'' . addslashes($row["titulo"]) . '\', \'' . addslashes($row["descricao"]) . '\')">';
            }
        } else {
            echo "Nenhuma imagem disponível.";
        }
        ?>
    </div>
</div>

<!-- Modal para exibir título e descrição -->
<div class="modal" id="imageModal" onclick="closeModal()">
    <div class="modal-content" onclick="event.stopPropagation()">
        <button onclick="closeModal()">×</button>
        <h2 id="modalTitle"></h2>
        <p id="modalDescription"></p>
    </div>
</div>

<div style="display: flex; justify-content: center; padding: 20px;">
<button onclick="window.location.href='postar.html'" style="background-color: #28a745; color: white; padding: 10px 20px; border: none; border-radius: 5px; font-size: 16px; cursor: pointer;">
    Postar Alien
</button>

</div>

</body>
</html>
